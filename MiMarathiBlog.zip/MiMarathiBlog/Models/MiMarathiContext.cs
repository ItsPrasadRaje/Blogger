﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MiMarathiBlog.Models
{
    public class MiMarathiContext : DbContext
    {
        public DbSet<Post> post {  get; set; }
        public DbSet<Users> user {  get; set; }
        public DbSet<comment> comment { get; set; }
        public DbSet<Liked> liked { get; set; }

    }
}