﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MiMarathiBlog.Models
{
    public class comment
    {
        [Key]
        public int Comment_id { get; set; }
        public  string Comment_Date {  get; set; }
        public string Comment { get; set; }
        public string LikedUserName { get; set; }
        public virtual ICollection<Post> Posts { get; set; }

        public int PId { get; set; }
        [ForeignKey("PId")]
        public Post post { get; set; }

    }
}