﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MiMarathiBlog.Models
{
    public class Post
    {
        [Key]
        public int PId { get; set; }

        public string Post_author {  get; set; }

        public string Post_date { get; set; }

        public string Post_title { get; set; }

        public string Post_Content { get; set; }
        public string Post_Status { get; set; }
        public string Categories { get; set; }
        public string Post_Img { get; set; }


        public int Id { get; set; }
        [ForeignKey("Id")]
        public Users User { get; set; }


        public virtual ICollection<comment> Comments { get; set; }
        public virtual ICollection<Liked> LikedPosts { get; set; }
       
        

        [NotMapped]
        public HttpPostedFileBase Blogimg { get; set; } 
      
    }
}