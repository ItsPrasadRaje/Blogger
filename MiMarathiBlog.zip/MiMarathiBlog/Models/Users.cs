﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MiMarathiBlog.Models
{
    public class Users
    {
        [Key]
        public int Id { get; set; }

        public string User_login { get; set; }

        public string User_password { get; set; }

        public string User_Nicename {  get; set; }

        public string User_email { get; set; }
        public string UPhoNum { get; set; }
        public string UDOB { get; set; }

        public string User_url { get; set; }

        public string User_registered_date {  get; set; }

        public string User_Status {  get; set; }

        public virtual ICollection<Post> Posts { get; set; }
      

        [NotMapped]
        public HttpPostedFileBase Uprofile  { get; set; }

       
    }
}