﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MiMarathiBlog.Models;

namespace MiMarathiBlog.Controllers
{

    public class HomeController : Controller
    {

        MiMarathiContext mi = new MiMarathiContext();
        // GET: Home
        public ActionResult Index()
        {
            if (Session["u"] == null)
            {
                return RedirectToAction("Login", "User");
            }
            var k = mi.post.Include(x=>x.User).ToList();
            return View(k);
        }

        
       
        public ActionResult ReadBlog(int id)
        {
            var p =mi.post.Find(id);
            Session["xyz"] = p;
            var com = mi.comment.Where(k=>k.PId == id).ToList();
            Session["comme"] = com;
           var c= Session["xyz"];
            return View(p);
        }
        [HttpPost]
        public ActionResult ReadBlog(comment c)
        {
            if (Session["u"] == null)
            {

            }
            c.LikedUserName = Session["u"].ToString();
            mi.comment.Add(c);
            mi.SaveChanges();
            var x= Session["xyz"];
            return View(x);
        }
        public ActionResult Like (Liked l)
        {
            if (Session["u"] == null)
            {

            }
          var uname = Session["u"].ToString();
            var x = mi.liked.Where(p=>p.LikedUserName==uname && p.PId==l.PId).SingleOrDefault();
            int j =  x.like_id;

            if (x != null)
            {
                
                mi.liked.Remove(j);
                mi.SaveChanges();
            }
            else
            {
                l.LikedUserName = Session["u"].ToString();
                l.Like = "1";
                mi.liked.Add(l);
                mi.SaveChanges();

            }
            return View(x);
        }
        public ActionResult Post()
        {
            var x = mi.post.ToList();
            return View(x);
        }

        public ActionResult WriteBlog()
        {
            if (Session["u"] == null)
            {
                return RedirectToAction("Login", "User");
            }
            var username = Session["u"] as string;
            var k = mi.user.Where(x => x.User_login == username).SingleOrDefault();

            return View(k);
        }
        [HttpPost]
        public ActionResult WriteBlog(Post p)
        {
            string Iname = Path.GetFileNameWithoutExtension(p.Blogimg.FileName);
            string ex = Path.GetExtension(p.Blogimg.FileName);

            Iname = Iname + ex;

            p.Post_Img = "~/Gallery/" + Iname;

            Iname = Path.Combine(Server.MapPath("~/Gallery/") + Iname);

            p.Blogimg.SaveAs(Iname);
            p.Post_author = Session["u"].ToString();
            //p.Id.ToString()= Session["id"].ToString();
            
                
            mi.post.Add(p);
            mi.SaveChanges();

            return RedirectToAction("Post");
        }


        public ActionResult Profile()
        {
           
            var username = Session["u"] as string;
            var k = mi.user.Where(x => x.User_login == username).SingleOrDefault();

            
            return View(k);
        }



        [HttpPost]
        public ActionResult Profile(Users p)
        {

            Users ad = new Users();
            ad.Id = p.Id;
            ad.User_login = p.User_login;
            ad.User_password = p.User_password;
            ad.User_Nicename = p.User_Nicename;
            ad.UPhoNum = p.UPhoNum;
            ad.UDOB = p.UDOB;
            ad.User_registered_date = p.User_registered_date;
            ad.User_Status = p.User_Status;
            if (p.Uprofile != null)
            {
                string Iname = Path.GetFileNameWithoutExtension(p.Uprofile.FileName);
                string ex = Path.GetExtension(p.Uprofile.FileName);

                Iname = Iname + ex;

                p.User_url = "~/Gallery/" + Iname;

                Iname = Path.Combine(Server.MapPath("~/Gallery/") + Iname);

                p.Uprofile.SaveAs(Iname);
                ad.User_url = p.User_url;
            }
            else 
            { 
               ad.User_url=p.User_url;
            }
            mi.user.AddOrUpdate(p);
            mi.SaveChanges();

            return RedirectToAction("Profile");
        }




    }
}