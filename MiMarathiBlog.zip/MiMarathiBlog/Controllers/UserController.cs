﻿using MiMarathiBlog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiMarathiBlog.Controllers
{
    public class UserController : Controller
    {
        MiMarathiContext mi = new MiMarathiContext();
        // GET: User
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Login(Users Uk)
        {
            mi.user.Add(Uk);
            mi.SaveChanges();
            return View();
        }

        [HttpPost]
        public ActionResult Login1(Users Ch)
        {

            var k = mi.user.Where(x=>x.User_login==Ch.User_login && x.User_password==Ch.User_password).SingleOrDefault();
            if (k != null)
            {
                Session["u"]=Ch.User_login;
                //Session["id"]=k.Id;
                return RedirectToAction("Index","Home");
            }
            else
            {
                return RedirectToAction("Login");
            }

            return View();
        }
    }
}